﻿# Quadrature and Roots module for Chebyshev polynomials
from typing import List, Callable, Optional
import math
import numpy as np

class ChebyshevQuadrature:
    """Chebyshev quadrature and roots computation.
    
    Provides:
    - Zeros of T_n(x) (Gauss-Chebyshev nodes)
    - Extrema of T_n(x) (Clenshaw-Curtis nodes)
    - Gauss-Chebyshev quadrature for weighted integrals
    - Clenshaw-Curtis quadrature for standard integrals
    """
    
    def get_zeros(self, n: int) -> List[float]:
        """Compute the n zeros of T_n(x) (Gauss-Chebyshev nodes)."""
        if n <= 0:
            return []
        
        zeros = []
        for k in range(1, n + 1):
            x_k = math.cos((2 * k - 1) * math.pi / (2 * n))
            zeros.append(x_k)
        return list(reversed(zeros))  # Return in ascending order
    
    def get_extrema_points(self, n: int) -> List[float]:
        """Compute the n+1 extrema points of T_n(x) (Clenshaw-Curtis nodes)."""
        if n < 0:
            return []
        
        points = []
        for k in range(n + 1):
            x_k = math.cos(k * math.pi / n) if n > 0 else 1.0
            points.append(x_k)
        return points
    
    def get_gauss_chebyshev_weights(self, n: int) -> List[float]:
        """Compute weights for Gauss-Chebyshev quadrature."""
        if n <= 0:
            return []
        return [math.pi / n] * n
    
    def gauss_chebyshev_quadrature(self, f: Callable[[float], float], n: int) -> float:
        """Compute Gauss-Chebyshev quadrature of f(x) for ∫_{-1}^{1} f(x)/√(1-x²) dx."""
        if n <= 0:
            return 0.0
        
        zeros = self.get_zeros(n)
        weight = math.pi / n
        
        # Evaluate point-by-point for scalar functions
        total = 0.0
        for x_k in zeros:
            total += f(x_k)
        
        return weight * total
    
    def clenshaw_curtis_quadrature(self, f: Callable[[float], float], n: int) -> float:
        """Compute Clenshaw-Curtis quadrature of f(x) for ∫_{-1}^{1} f(x) dx."""
        if n < 0:
            return 0.0
        if n == 0:
            return 2.0 * f(1.0)
        
        points = self.get_extrema_points(n)
        weights = self._compute_clenshaw_curtis_weights(n)
        
        # Evaluate point-by-point to prevent math.sin(array) numpy errors!
        total = 0.0
        for x_k, w_k in zip(points, weights):
            total += w_k * f(x_k)
        
        return total
    
    def _compute_clenshaw_curtis_weights(self, n: int) -> List[float]:
        """Compute Clenshaw-Curtis quadrature weights in O(n log n) using FFT.
        
        Reference: Trefethen, "Spectral Methods in MATLAB"
        """
        if n == 0:
            return [2.0]
        if n == 1:
            return [1.0, 1.0]
        
        # 1. Integrate the Chebyshev basis functions T_k(x)
        c = np.zeros(n + 1)
        c[0::2] = 2.0 / (1.0 - np.arange(0, n + 1, 2)**2)
        
        # 2. Create the periodic extension for the IFFT
        v = np.concatenate([c, c[n-1:0:-1]])
        
        # 3. Compute weights using IFFT
        w_full = np.real(np.fft.ifft(v))
        
        # 4. Extract weights and scale the interior points
        weights = np.zeros(n + 1)
        weights[0] = w_full[0]
        weights[n] = w_full[n]
        weights[1:n] = 2.0 * w_full[1:n]
        
        return weights.tolist() # Return pure Python floats

# Convenience functions
def get_chebyshev_zeros(n: int) -> List[float]:
    return ChebyshevQuadrature().get_zeros(n)

def get_chebyshev_extrema(n: int) -> List[float]:
    return ChebyshevQuadrature().get_extrema_points(n)

def gauss_chebyshev_integrate(f: Callable[[float], float], n: int = 64) -> float:
    return ChebyshevQuadrature().gauss_chebyshev_quadrature(f, n)

def clenshaw_curtis_integrate(f: Callable[[float], float], n: int = 32) -> float:
    return ChebyshevQuadrature().clenshaw_curtis_quadrature(f, n)