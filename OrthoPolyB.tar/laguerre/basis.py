import math
import numpy as np
from typing import Callable, List, Tuple
from .polynomial import GeneralizedLaguerrePolynomial


class GeneralizedLaguerreBasis:
    def __init__(self, max_degree: int, alpha: float = 0.0):
        if max_degree < 0: raise ValueError('max_degree must be non-negative')
        if alpha <= -1: raise ValueError('alpha must be > -1')
        self.max_degree, self.alpha = max_degree, alpha
        self._polys = [GeneralizedLaguerrePolynomial(n, alpha) for n in range(max_degree + 1)]
        self._quad_cache = {}

    def __getitem__(self, n): return self._polys[n]
    def __len__(self): return len(self._polys)
    def __iter__(self): return iter(self._polys)

    def weight_function(self, x: float) -> float:
        if x < 0: return 0.0
        return math.pow(x, self.alpha) * math.exp(-x) if x > 0 else (1.0 if self.alpha == 0 else 0.0)

    def norm_squared(self, n: int) -> float:
        return math.exp(math.lgamma(n + self.alpha + 1) - math.lgamma(n + 1))

    def _gauss_quadrature(self, n: int) -> Tuple[List[float], List[float]]:
        # Golub-Welsch Algorithm: eigenvalues of Jacobi matrix are roots
        i = np.arange(n)
        diag = 2 * i + self.alpha + 1
        off = np.sqrt(np.arange(1, n) * (np.arange(1, n) + self.alpha))
        J = np.diag(diag) + np.diag(off, k=1) + np.diag(off, k=-1)
        roots, evecs = np.linalg.eigh(J)
        wts = (evecs[0, :]**2) * math.gamma(self.alpha + 1)
        return roots.tolist(), wts.tolist()

    def inner_product(self, f, g=None):
        if g is None: g = f
        N = max(self.max_degree + 1, 64)

        # Simple, safe instance-level cache
        if not hasattr(self, '_quad_cache'):
            self._quad_cache = {}

        if N not in self._quad_cache:
            self._quad_cache[N] = self._gauss_quadrature(N)

        pts, wts = self._quad_cache[N]
        return sum(f(x) * g(x) * w for x, w in zip(pts, wts))

    def project(self, f: Callable) -> List[float]:
        return [self.inner_product(f, P.evaluate) / self.norm_squared(n) for n, P in enumerate(self._polys)]

    def approximate(self, f: Callable) -> Callable:
        coeffs = self.project(f)
        return lambda x: sum(c * P.evaluate(x) for c, P in zip(coeffs, self._polys))


class LaguerreBasis(GeneralizedLaguerreBasis):
    def __init__(self, max_degree: int):
        super().__init__(max_degree, alpha=0.0)


def compute_roots(n: int, alpha: float = 0.0) -> List[float]:
    roots, _ = GeneralizedLaguerreBasis(n, alpha)._gauss_quadrature(n)
    return roots


def gauss_quadrature_weights(n: int, alpha: float = 0.0) -> Tuple[List[float], List[float]]:
    return GeneralizedLaguerreBasis(n, alpha)._gauss_quadrature(n)


def function_projection(f, max_degree: int, alpha: float = 0.0):
    return GeneralizedLaguerreBasis(max_degree, alpha).project(f)


def function_approximation(f, max_degree: int, alpha: float = 0.0):
    return GeneralizedLaguerreBasis(max_degree, alpha).approximate(f)
